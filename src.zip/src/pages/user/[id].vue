    <template>
    Buscar as informações do usuário: {{ user.name }}
</template>
<script setup>
    import { ref } from 'vue';
    import { useRoute } from 'vue-router';
    const $route = useRoute();
    const users = ref([
        { id: 1, name: 'João da Silva' },
        { id: 2, name: 'Maria da Silva' },
        { id: 3, name: 'José da Silva' },
        { id: 4, name: 'Ana da Silva' },
    ]);
    const user = users.value.find(user => user.id == $route.params.id);    
</script>