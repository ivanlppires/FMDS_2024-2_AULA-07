<template>
    <v-list>
        <v-list-subheader>Clientes</v-list-subheader>
        <v-list-item>
            <v-btn variant="text" to="/user/1">João da Silva</v-btn>
        </v-list-item>
        <v-list-item>
            <v-btn variant="text" to="/user/2">Maria da Silva</v-btn>
        </v-list-item>
    </v-list>
</template>